#include "ros/ros.h"                          // ROS Default Header File
#include "betabot_msgs/square_service.h"
#include <tf/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>
#include "geometry_msgs/Twist.h"
#include <stdlib.h>
#include <ctime>
#include <cmath>
#include <math.h>

struct Quaternion {
    double w, x, y, z;
};
struct position
{
    double x;
    double y;
};


struct EulerAngles {
    double roll, pitch, yaw;
};

EulerAngles ToEulerAngles(Quaternion q) 
{
    EulerAngles angles;

    // roll (x-axis rotation)
    double sinr_cosp = 2 * (q.w * q.x + q.y * q.z);
    double cosr_cosp = 1 - 2 * (q.x * q.x + q.y * q.y);
    angles.roll = std::atan2(sinr_cosp, cosr_cosp);

    // pitch (y-axis rotation)
    double sinp = 2 * (q.w * q.y - q.z * q.x);
    if (std::abs(sinp) >= 1)
        angles.pitch = std::copysign(M_PI / 2, sinp); // use 90 degrees if out of range
    else
        angles.pitch = std::asin(sinp);

    // yaw (z-axis rotation)
    double siny_cosp = 2 * (q.w * q.z + q.x * q.y);
    double cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z);
    angles.yaw = std::atan2(siny_cosp, cosy_cosp);

    return angles;
}

class Mover{
    public:
       ros::Subscriber sub; 
       ros::NodeHandle n;
       ros::ServiceServer square_service;
       ros::Publisher pub;
      geometry_msgs::Twist msgg;
    Mover(){
        ROS_INFO("Intiating the move square command");
        sub= n.subscribe("/odom",1000,&Mover::OdomCallback,this);
        square_service = n.advertiseService("square_service",&Mover::move,this);
        pub = n.advertise<geometry_msgs::Twist>("cmd_vel",200);
    }
    double getDistance (position a,position b)
    {
        return sqrt(pow(a.x - b.x,2)+pow(a.y - b.y,2));
    }
    bool move(betabot_msgs::square_service::Request &request,
              betabot_msgs::square_service::Response &response)
    {
        ROS_INFO("Move Square called");
       
        // ros::Subscriber sub = n.subscribe("odom", 1000, );
        
        for(int j=0; j<request.repetitions;j++)
        {
            for(int i=0; i<4; i++)
            {
                // the loop responsible to move it to certain distance
                 initLocation= location;
                 initAngles=angles;
                 while(ros::ok())
                 {
                    msgg.linear.x = 0.5;
                    pub.publish(msgg);
                    ROS_INFO_STREAM("("<<location.x<<" , "<<location.y<< ") , ("<<initLocation.x<<" , "<<initLocation.y<< ")");
                    if (getDistance(location,initLocation)>=request.side)
                    {
                        break;
                    }
                
                 }
                 ROS_INFO_STREAM("turning 90 degrees");
                 sleep(500);
                 initLocation= location;
                 initAngles=angles;
                 while(ros::ok())
                 {
                    msgg.angular.z = 0.8;
                    pub.publish(msgg);
                    ROS_INFO_STREAM("Sending the command:"<<" angular="<<msgg.angular.z);
                    if (angles.yaw-initAngles.yaw>=90)
                    {
                        break;
                    }
                 }  
            }
        }
        response.success = true;
        return true;
    }
     void OdomCallback(const nav_msgs::OdometryConstPtr &msg){
          ROS_INFO_STREAM("Hiiiii");
            location.x = msg->pose.pose.position.x;  // get the robot x pose from the odom topic
            location.y= msg->pose.pose.position.y;  // get the robot y pose from the odom topic
            
            q.w=msg->pose.pose.orientation.w;
            q.x=msg->pose.pose.orientation.x;
            q.y=msg->pose.pose.orientation.y;
            q.z=msg->pose.pose.orientation.z;
            
            angles=ToEulerAngles(q);
            }

    private:
    EulerAngles angles;
    EulerAngles initAngles;
    Quaternion q;
    position location;
    position initLocation;
    


};


int main(int argc, char **argv)
{
    ros::init(argc, argv, "mover");
    Mover mover;


    ros::spin();
    
    return 0;


}





