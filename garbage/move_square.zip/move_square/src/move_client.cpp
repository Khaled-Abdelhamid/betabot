#include "ros/ros.h"                         // ROS Default Header File
#include "betabot_msgs/square_service.h"
#include "betabot_msgs/square_serviceRequest.h"
#include "betabot_msgs/square_serviceResponse.h"
#include <iostream>
#include <cstdlib>


int main(int argc, char **argv)
{
    ros::init(argc, argv, "move_square_client");
    ros::NodeHandle n;

    ROS_INFO("passing the service command");

    ros::ServiceClient square_service = n.serviceClient<betabot_msgs::square_service>("square_service");

    betabot_msgs::square_serviceRequest req;
    betabot_msgs::square_serviceResponse res;
    
    req.side = atoll(argv[1]);
    req.repetitions = atoll(argv[2]);
    square_service.call(req, res);

    

    return 0;
}